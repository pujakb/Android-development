package com.inoek.apps.assgn2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    private EditText eUrl, ePhNumber;
    private Button bLaunch, bRing, bClose;
    final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eUrl = (EditText) findViewById(R.id.textURL);
        ePhNumber = (EditText) findViewById(R.id.textPhone);
        bLaunch = (Button) findViewById(R.id.bLaunch);
        bRing = (Button) findViewById(R.id.bRing);
        bClose = (Button) findViewById(R.id.bClose);

        // check for permissions
        if(ActivityCompat.checkSelfPermission(getApplicationContext(),Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED)
        {
            EnableRuntimePermission();
        }

        // set up on click listeners

        // open a web link

        bLaunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = eUrl.getText().toString();
                if(URLUtil.isValidUrl(url)) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Please enter a http:// or https:// valid url", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bRing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                String phone = ePhNumber.getText().toString();
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:"+phone));
                startActivity(callIntent);
            }
        });

        bClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void showMessageOKCancel(String message) {
        // shows alert message if needed, it can be used for anything.
        new AlertDialog.Builder(MainActivity.this).setMessage(message).create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS: {
                Map<String, Integer> perms = new HashMap<String, Integer>();
                // Initial
                // all the permissions to be added in this list "perms"
                perms.put(Manifest.permission.CALL_PHONE,
                        PackageManager.PERMISSION_GRANTED);

                // Fill with results
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                // Check for ACCESS_FINE_LOCATION
                if (perms.get(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    // All Permissions Granted
                    Toast.makeText(MainActivity.this, "Thanks!",
                            Toast.LENGTH_SHORT).show();
                    //    new UpdateContactsAsyncPermissions().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                } else {
                    // Permission Denied
                    showMessageOKCancel("Sorry!, you denied my Permission Requests!");
                    finish();
                }
            }
            break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions,
                        grantResults);
        }
    }

    public void EnableRuntimePermission() {
        // check for build version number, as this requirement starts from Android 5.0
        // Any new permissions, should be first registered in AndroidManifest.xml before getting added here.
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> permissionsNeeded = new ArrayList<String>();
            final List<String> permissionsList = new ArrayList<String>();
            // Add required permissions if not added

            if (!addPermission(permissionsList,
                    Manifest.permission.CALL_PHONE))
                permissionsNeeded.add("Call Phone");

            if (permissionsList.size() > 0) {
                // request for permissions
                requestPermissions(
                        permissionsList.toArray(new String[permissionsList
                                .size()]),
                        REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                return;
            }
        }
    }

    private boolean addPermission(List<String> permissionsList,
                                  String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                // Check for Rationale Option
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (!shouldShowRequestPermissionRationale(permission))
                        return false;
                }
            }
        }
        return true;
    }
}
