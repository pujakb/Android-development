package com.sjsu.pk.assign31;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity1 extends AppCompatActivity {

    //defining and declaring variables actors
    Button generateButton, cancelButton;
    EditText currencyInput;
    Spinner spinnerCurrencySelector;
    CurrencyConverted currencyConvertedReceiver;
    IntentFilter intentFilter;
    double convertedAmt = 0;
    String converstionStats = "";
    TextView resultText;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        Bundle _b = getIntent().getExtras();
        //connecting with UI
        generateButton = (Button) findViewById(R.id.generate_button);
        cancelButton = (Button) findViewById(R.id.cancel_button);
        currencyInput = (EditText) findViewById(R.id.givenAmount);
        spinnerCurrencySelector = (Spinner) findViewById(R.id.currencySelector);
        resultText = (TextView) findViewById(R.id.result_text);

        //starting the receiver ; object
        currencyConvertedReceiver = new CurrencyConverted();
        intentFilter = new IntentFilter("com.sjsu.pk.assign31.CURRENCY_CONVERTED"); //waits for currencyconverted

        //if _b = null fine ; or update the value on UI from braoadcast receieved from CURRENCY_CONVERTED
        if(_b != null) {
            convertedAmt = _b.getDouble("converted_amt");
            String convertedAmtText = String.format("%.2f",convertedAmt);
            converstionStats = _b.getString("converted_status");
            long currencyValue = _b.getLong("currency_amount");
            int index_currency = _b.getInt("index_currency_format");
            spinnerCurrencySelector.setSelection(index_currency);
            currencyInput.getText().clear();
            currencyInput.setText(String.valueOf(currencyValue));
            String currencyFormat = _b.getString("currency_format");
            String convertedText = "";
            if(convertedAmt == 0)
            {
                convertedText += converstionStats;
            }
            else
            {
                convertedText = "Dollar $ amount "+String.valueOf(currencyValue)+" converted to "
                        + convertedAmtText+" "+ currencyFormat +" "+converstionStats;
            }
            resultText.setText(convertedText);
        }

        //to send currency_convert broadcast
        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textInput = currencyInput.getText().toString();
                if(!textInput.isEmpty()) {
                    long currencyAmt = Long.parseLong(textInput);
                    Intent intent = new Intent("com.sjsu.pk.assign31_processor.CURRENCY_CONVERT");
                    sendBroadcast(intent);
                    PackageManager pm = getApplicationContext().getPackageManager();
                    Intent launchIntent = pm.getLaunchIntentForPackage("com.sjsu.pk.assign31_processor");
                    Bundle b = new Bundle();
                    String currencyFormat = spinnerCurrencySelector.getSelectedItem().toString();
                    int itemIndex = spinnerCurrencySelector.getSelectedItemPosition();
                    b.putLong("currency_amount", currencyAmt);
                    b.putString("currency_format", currencyFormat);
                    b.putInt("index_currency_format", itemIndex);
                    launchIntent.putExtras(b);
                    getApplicationContext().startActivity(launchIntent);
                    finish();
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // exits from app
               finish();
            }
        });

    }
//when app is opened
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(currencyConvertedReceiver, intentFilter);
    }
//for uninstalling
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(currencyConvertedReceiver);
    }
}
