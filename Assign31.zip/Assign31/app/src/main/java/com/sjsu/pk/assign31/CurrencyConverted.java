package com.sjsu.pk.assign31;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by anupamchugh on 11/04/16.
 */



public class CurrencyConverted extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {


//to generate logcat logs
        Log.d("API123",""+intent.getAction());
//waits for currency_converted message
        if(intent.getAction().equals("com.sjsu.pk.assign31.CURRENCY_CONVERTED"))
        //message sent to user
        {
            Toast.makeText(context, "Currency conversion initated..", Toast.LENGTH_LONG).show();
        }

    }

}
