package com.sjsu.pk.datastorageapp;

import android.provider.BaseColumns;

public class Item {
    public Item(){

    }

    public static abstract class TableInfo implements BaseColumns {

        public static final String ITEM_NAME = "item_name";
        public static final String ITEM_DESCRIPTION = "item_description";
        public static final String ITEM_PRICE = "item_price";
        public static final String ITEM_REVIEW = "item_review";

        public static final String DATABASE_NAME = "myDB";
        public static final String TABLE_NAME = "itemInfo";

    }
}