package com.sjsu.pk.datastorageapp;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class SearchActivity extends Activity {

    Context ctx = this;
    ListView outputView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        outputView      = (ListView) (findViewById(R.id.output_view));
        outputView.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList()));
    }

    public void search(View view){
        ArrayAdapter<String> adapter =  (ArrayAdapter<String>) outputView.getAdapter();;
        String name, description, review;
        int price;

        EditText keywordEditTest = (EditText) findViewById(R.id.input_search);
        String keyword = keywordEditTest.getText().toString();

        System.out.println(keyword);

        DatabaseOperations db = new DatabaseOperations(ctx);

        Cursor cr = db.getData(db, keyword);
        Toast.makeText(getBaseContext(), "Data has been retrieved successfully", Toast.LENGTH_SHORT).show();



        cr.moveToFirst();
        do{
            name = cr.getString(0);
            description = cr.getString(1);
            price = cr.getInt(2);
            review = cr.getString(3);
            System.out.println(name+", "+description+", "+price+", "+review);

            String temp = "Name: "+name+"\nDescription: "+description + "\nPrice: " +price + "\nReview: " +review+ "\n";
            adapter.add(temp);

        }while (cr.moveToNext());

    }
}
