package com.sjsu.pk.datastorageapp;

import android.app.Activity;
import android.content.ClipData;
import android.database.Cursor;
import android.database.sqlite.SQLiteQuery;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.text.TextUtils;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class InsertActivity extends Activity
{

    Context ctx = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
    }

    public void addData(View view){

        ItemPOJO i = new ItemPOJO();

        EditText iname = (EditText) findViewById(R.id.iname);
        String item_name = iname.getText().toString();
        i.setName(item_name);

        EditText idescription = (EditText) findViewById(R.id.idescription);
        String item_description = idescription.getText().toString();
        i.setDescription(item_description);

        EditText iprice = (EditText) findViewById(R.id.iprice);
        int item_price = Integer.parseInt(iprice.getText().toString());
        i.setPrice(item_price);

        EditText ireview = (EditText) findViewById(R.id.ireview);
        String item_review = ireview.getText().toString();
        i.setReview(item_review);

        DatabaseOperations db = new DatabaseOperations(ctx);

        db.insertData(db, i);
        Toast.makeText(getBaseContext(), "Data Inserted successfully", Toast.LENGTH_SHORT).show();
        finish();

    }

}
