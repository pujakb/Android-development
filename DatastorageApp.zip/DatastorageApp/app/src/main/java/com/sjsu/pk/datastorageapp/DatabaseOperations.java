package com.sjsu.pk.datastorageapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseOperations extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public String CREATE_QUERY = "CREATE TABLE "+Item.TableInfo.TABLE_NAME+" ("+ Item.TableInfo.ITEM_NAME+" TEXT, "+ Item.TableInfo.ITEM_DESCRIPTION+" TEXT, "+ Item.TableInfo.ITEM_PRICE+" INTEGER, "+ Item.TableInfo.ITEM_REVIEW+" TEXT);";

    public DatabaseOperations(Context context) {
        super(context, Item.TableInfo.DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("Database Operations ", "Database Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_QUERY);
        Log.d("Database Operations ", "Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertData(DatabaseOperations dbop, ItemPOJO itempojo){

        SQLiteDatabase sqdb = dbop.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Item.TableInfo.ITEM_NAME, itempojo.getName());
        cv.put(Item.TableInfo.ITEM_DESCRIPTION, itempojo.getDescription());
        cv.put(Item.TableInfo.ITEM_PRICE, itempojo.getPrice());
        cv.put(Item.TableInfo.ITEM_REVIEW, itempojo.getReview());

        Long k = sqdb.insert(Item.TableInfo.TABLE_NAME, null, cv);
        Log.d("Database Operations ", "Row Inserted");

    }

    public Cursor getData(DatabaseOperations dbop, String keyword){

        SQLiteDatabase sqdb = dbop.getReadableDatabase();
        String[] columns = {Item.TableInfo.ITEM_NAME, Item.TableInfo.ITEM_DESCRIPTION, Item.TableInfo.ITEM_PRICE, Item.TableInfo.ITEM_REVIEW};

        String whereClause = Item.TableInfo.ITEM_NAME+" = ?";
        String[] whereArgs = {keyword};

        Cursor cr = sqdb.query(Item.TableInfo.TABLE_NAME, columns, whereClause, whereArgs, null, null, null);

        return cr;
    }
}
