package com.sjsu.pk.assign31_processor;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    //define and declare the variables / actors
    CurrencyReceiver receiver;
    IntentFilter intentFilter;
    TextView currencyAmt;
    TextView currencyFormat;
    Button applyButton;
    Button cancelButton;
    int index_currency_format = 0;
    long currency_value = 0;
    String currency_conversion_format = "";

    @Override
    //function that runs the app
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle b = getIntent().getExtras();
        currencyAmt = (TextView) findViewById(R.id.currency_amt);
        currencyFormat = (TextView) findViewById(R.id.currency_format);
        applyButton = (Button) findViewById(R.id.apply_button);
        cancelButton = (Button) findViewById(R.id.cancel_button);
        //update the values in bundle with the ones received from broadcast 'currency_convert'
        if(b != null) {
            currency_value = b.getLong("currency_amount");
            String dollarAmount = "Dollar Amount($): "+String.valueOf(currency_value);
            currencyAmt.setText(dollarAmount);
            currency_conversion_format = b.getString("currency_format");
            String convertTo = "Convert to : "+currency_conversion_format;
            currencyFormat.setText(convertTo);
            index_currency_format = b.getInt("index_currency_format");
        }
//new receiver
        receiver = new CurrencyReceiver();
        intentFilter = new IntentFilter("com.sjsu.pk.assign31_processor.CURRENCY_CONVERT");
//apply button logic to convert the currency
        applyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*
                British Pound ( 1 USD  = 0.71 British Pound), Euro (1 USD = 0.81 Euro), INR (1 USD = 64.39 INR)
                 */
                double convertedValue = 0;
                if(index_currency_format == 0)
                {
                   convertedValue = currency_value * 0.71;
                }
                else if(index_currency_format == 1)
                {
                    convertedValue = currency_value * 0.81;
                }
                else
                {
                    convertedValue = currency_value * 64.39;
                }
                //new intent created to send the message as currency converted
                Intent intent = new Intent("com.sjsu.pk.assign31.CURRENCY_CONVERTED");
                sendBroadcast(intent);
                PackageManager pm = getApplicationContext().getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage("com.sjsu.pk.assign31");
                Bundle b = new Bundle();
                b.putInt("index_currency_format", index_currency_format);
                b.putLong("currency_amount",currency_value);
                b.putString("currency_format",currency_conversion_format);
                b.putDouble("converted_amt", convertedValue);
                b.putString("converted_status", "Successfully!!");
                launchIntent.putExtras(b);
                getApplicationContext().startActivity(launchIntent);
                finish();
            }
        });
//cancel button logic
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("com.sjsu.pk.assign31.CURRENCY_CONVERTED");
                sendBroadcast(intent);
                PackageManager pm = getApplicationContext().getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage("com.sjsu.pk.assign31");
                Bundle b = new Bundle();
                b.putLong("currency_amount",currency_value);
                b.putString("currency_format",currency_conversion_format);
                b.putDouble("converted_amt", 0);
                b.putString("converted_status", "Sorry, Unable to process!!");
                launchIntent.putExtras(b);
                getApplicationContext().startActivity(launchIntent);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }
}
