package com.sjsu.pk.accelerometer;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // Defining Actors
    private EditText inputVal;
    private Button generateButton;
    private Button cancelButton;
    private static GenerateRandomDouble generateRandomDouble;
    private String outputTextValue;


    private class GenerateRandomDouble extends AsyncTask<Void, String, Void> {

        private int numberOfSimulations;

        public GenerateRandomDouble(int n)
        {
            numberOfSimulations = n;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            // cancel the task
            if(isCancelled())
            {
                return null;
            }

            for(int simulationCount = 0; simulationCount < numberOfSimulations; simulationCount++)
            {
                if(isCancelled())
                {
                    return null;
                }
                final Random randNum = new Random();
                outputTextValue =  "Simulation Count: "+String.valueOf(simulationCount+1);
                String xValueDouble = String.format("%.2f",100*randNum.nextDouble());
                outputTextValue += "\n X: "+xValueDouble;
                String yValueDouble = String.format("%.2f",100*randNum.nextDouble());
                outputTextValue += ", Y: "+yValueDouble;
                String zValueDouble = String.format("%.2f",100*randNum.nextDouble());
                outputTextValue += ", Z: "+zValueDouble;
                outputTextValue += "\n";
                publishProgress(xValueDouble,yValueDouble,zValueDouble,outputTextValue);
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            TextView xValue = (TextView) findViewById(R.id.x_value);
            TextView yValue = (TextView) findViewById(R.id.y_value);
            TextView zValue = (TextView) findViewById(R.id.z_value);
            TextView outputText = (TextView) findViewById(R.id.output_text);
            xValue.setText(values[0]);
            yValue.setText(values[1]);
            zValue.setText(values[2]);
            outputText.append(values[3]);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // connecting to views
        inputVal = (EditText)findViewById(R.id.input_value);
        generateButton = (Button) findViewById(R.id.generate_button);
        cancelButton = (Button) findViewById(R.id.cancel_button);

        // create listeners = alt+enter

        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int inputNumber = Integer.parseInt(inputVal.getText().toString());
                generateRandomDouble = new GenerateRandomDouble(inputNumber);
                generateRandomDouble.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(generateRandomDouble != null)
                {
                    generateRandomDouble.cancel(true);
                }
            }
        });
    }
}
