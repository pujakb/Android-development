package pk.sjsu.com.assg1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class Activity_B extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
    }
    @Override
    protected void onPause() {
        super.onPause();
        Activity_A.count++;
    }

    //
    public void finishActivityB(View v) {
        Intent intent = new Intent(Activity_B.this, Activity_A.class);
        startActivity(intent);
    }
}
