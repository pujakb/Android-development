package pk.sjsu.com.assg1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class Activity_C extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_c);
    }
    @Override
    protected void onPause() {
        super.onPause();
        Activity_A.count++;
    }

    public void finishDialog(View v) {
        Activity_C.this.finish();
    }
}
