package pk.sjsu.com.assg1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

public class Activity_A extends AppCompatActivity {

    public static Integer count = 1;
    TextView countView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);
        countView = (TextView)findViewById(R.id.editText2);
        countView.setText("Thread Counter: " + count.toString());
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        countView.setText("Thread Counter: " + count.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        countView.setText("Thread Counter: " + count.toString());
    }

    @Override
    protected void onPause() {
        super.onPause();
        Activity_A.count++;
        countView.setText("Thread Counter: " + count.toString());
    }

    public void startDialog(View v) {
        Intent intent = new Intent(Activity_A.this, Activity_C.class);
        startActivity(intent);
    }

    public void startActivityB(View v) {
        Intent intent = new Intent(Activity_A.this, Activity_B.class);
        startActivity(intent);
    }

    public void closeApp(View v) {
        Activity_A.this.finish();
    }

    public void finishActivityB(View view) {
    }
}

